GUI IS CURRENTLY BROKEN, ONLY USE THE CONFIG.

*****************************************
Depends on: ProtocolLib, Java 8, Spigot.
****************************************

TERMS OF SERVICE

- DO NOT DISTRIBUTE
- IF YOU HAVE ISSUES, MESSAGE ME.
- NO REFUNDS


MY IGN: ItemMeta - If you ever need me to log on and see violations.
********************************************************************

PERMISSIONS
* AC.STAFF - View alerts
* AC.ADMIN - JI command

COMMANDS
* /ji
* /ji reload
* /ji status <player>
* /ji bans
* /alerts
* /autoban cancel
* /jday
